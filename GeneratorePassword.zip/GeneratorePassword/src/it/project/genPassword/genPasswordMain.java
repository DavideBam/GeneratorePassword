package it.project.genPassword;

import java.util.Random;

public class genPasswordMain {

	public static void main(String[] args) {

		int length = 10; // lunghezza password
		System.out.println(generatePswd(length));
	}

	static char[] generatePswd(int len) {
		System.out.println("Your Password:");
		
		String charsCaps = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String chars = "abcdefghijklmnopqrstuvwxyz";
		String nums = "0123456789";
		String symbols = "!@#$%^&*_=+-/�.?<>)";

		String passSymbols = charsCaps + chars + nums + symbols; //unione di tutte le stringhe

		char[] password = new char[len];
		
		Random rnd = new Random();
		
		for (int i = 0; i < len; i++) {
			password[i] = passSymbols.charAt(rnd.nextInt(passSymbols.length())); // estrazione random dei caratteri

		}
		return password;
	}

}
